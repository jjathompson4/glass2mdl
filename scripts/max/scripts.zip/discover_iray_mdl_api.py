"""glass2mdl — Iray+ MDL scripting API discovery (read-only).

Answers the one question the public Iray+ docs leave open: can a script create
a material backed by a custom .mdl module from an MDL search path, and if so,
through which class and which properties?

Run this ON THE WORKSTATION, inside 3ds Max 2024, AFTER hand-creating one
Iray+ MDL material (any glass2mdl or validation-kit material) in the material
editor and assigning it to a selected object (or leaving it in the active
Slate/Compact editor slot).

    Scripting > Run Script... > discover_iray_mdl_api.py

It inspects the material and prints every class and property name it can see,
to the listener and to `discover_report.txt` next to this script (falling back
to the Max temp directory). Paste that file back into a glass2mdl session —
its contents decide whether `glass2mdl_apply.py` can bind materials fully
automatically or needs the one-drag-per-type fallback.

Read-only: creates nothing, modifies nothing.
"""

import os
import sys
import traceback

try:
    from pymxs import runtime as rt
except ImportError:  # keeps the file importable/compilable outside Max
    rt = None

LINES = []


def out(text=""):
    LINES.append(text)
    print(text)


def guarded(label, fn):
    """Run fn, report its value or the exception — never abort the survey."""
    try:
        value = fn()
        out(f"  {label}: {value!r}")
        return value
    except Exception as exc:  # noqa: BLE001 - survey must survive anything
        out(f"  {label}: <error: {exc}>")
        return None


def survey_classes():
    out("== Material / texture classes matching 'iray' or 'mdl' ==")
    for collection_name in ("material", "textureMap"):
        try:
            collection = getattr(rt, collection_name)
            names = [str(c) for c in collection.classes]
        except Exception as exc:  # noqa: BLE001
            out(f"  <could not enumerate {collection_name}.classes: {exc}>")
            continue
        hits = [n for n in names if "iray" in n.lower() or "mdl" in n.lower()]
        out(f"  {collection_name}.classes ({len(names)} total):")
        for name in hits or ["<no matches>"]:
            out(f"    {name}")
    out()


def find_target_material():
    """Selected object's material first, then the active editor slot."""
    try:
        if rt.selection.count > 0:
            mat = rt.selection[0].material
            if mat is not None:
                out(f"Target: material of selected object '{rt.selection[0].name}'")
                return mat
    except Exception:  # noqa: BLE001
        pass
    try:
        mat = rt.medit.GetCurMtl()
        if mat is not None:
            out("Target: active material editor slot")
            return mat
    except Exception:  # noqa: BLE001
        pass
    return None


def survey_material(mat, depth=0):
    indent = "  " * depth
    out(f"{indent}== Material survey ==")
    guarded("classOf", lambda: rt.classOf(mat))
    guarded("superClassOf", lambda: rt.superClassOf(mat))
    guarded("name", lambda: mat.name)

    out(f"{indent}-- getPropNames --")
    props = guarded("getPropNames", lambda: list(rt.getPropNames(mat))) or []
    for prop in props:
        pname = str(prop)
        guarded(
            f"{pname} (value, class)",
            lambda p=prop: (rt.getProperty(mat, p), rt.classOf(rt.getProperty(mat, p))),
        )

    out(f"{indent}-- irpGetPropertyList (Iray+ view of the same material) --")
    irp_props = guarded("irpGetPropertyList", lambda: list(rt.irpGetPropertyList(mat)))
    if irp_props:
        for prop in irp_props:
            guarded(f"irp {prop}", lambda p=prop: rt.irpGetProperty(mat, str(p)))

    # Multi-Sub wrappers: survey each sub-material one level down, since the
    # MDL-backed class may be sitting in a slot rather than on the node.
    try:
        if rt.isKindOf(mat, rt.MultiMaterial) and depth == 0:
            for i in range(int(mat.numsubs)):
                sub = mat.materialList[i]
                if sub is not None:
                    out()
                    out(f"-- Multi-Sub slot {i + 1} --")
                    survey_material(sub, depth=1)
    except Exception:  # noqa: BLE001
        pass


def report_path():
    try:
        here = os.path.dirname(os.path.abspath(__file__))
        if os.path.isdir(here):
            return os.path.join(here, "discover_report.txt")
    except NameError:
        pass
    return os.path.join(str(rt.getDir(rt.name("temp"))), "discover_report.txt")


def main():
    if rt is None:
        print("pymxs not available — run this inside 3ds Max.")
        return

    out("glass2mdl Iray+ MDL API discovery")
    guarded("3ds Max version", lambda: rt.maxVersion())
    guarded("Iray+ API present (irpGetPropertyList)", lambda: hasattr(rt, "irpGetPropertyList"))
    out()

    survey_classes()

    mat = find_target_material()
    if mat is None:
        out("No target material found.")
        out("Create an Iray+ MDL material in the material editor, assign it to a")
        out("selected object (or keep it in the active slot), and run this again.")
    else:
        survey_material(mat)

    path = report_path()
    try:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("\n".join(LINES) + "\n")
        out()
        out(f"Report written to: {path}")
    except OSError:
        out()
        out("Could not write the report file — copy the listener output instead.")
        traceback.print_exc()


if __name__ == "__main__":
    main()
